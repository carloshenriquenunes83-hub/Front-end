# Meu Portfólio

Site pessoal feito para a disciplina de Desenvolvimento Front-end para Web (A2).

- **Autor:** Robert
- **Tecnologias:** HTML5, CSS3 (Flexbox, Grid, media queries), JavaScript, Git
- **Páginas:** index, currículo, formulário, multimídia, gráficos
- **Como rodar:** abra `index.html` no navegador. Não há dependências.
- **Recursos:** menu responsivo, tema claro/escuro salvo em `localStorage`, formulário validado.
- **Site publicado:** [cole aqui o link do deploy]
