(function(){
  var raiz=document.documentElement;
  try{var t=localStorage.getItem("tema");if(t)raiz.setAttribute("data-theme",t);}catch(e){}
  var b=document.getElementById("tema");
  if(b)b.addEventListener("click",function(){
    var novo=raiz.getAttribute("data-theme")==="dark"?"light":"dark";
    raiz.setAttribute("data-theme",novo);
    try{localStorage.setItem("tema",novo);}catch(e){}
  });
  var f=document.getElementById("contato");
  if(f)f.addEventListener("submit",function(ev){
    ev.preventDefault();
    var n=f.nome.value.trim();
    document.getElementById("retorno").textContent="Obrigado, "+n+"! Mensagem registrada (demonstração).";
    try{localStorage.setItem("ultimoContato",n);}catch(e){}
    f.reset();
  });
  var c=document.getElementById("grafico");
  if(c){
    var x=c.getContext("2d"),d=[4,7,5,9,6],l=["S1","S2","S3","S4","S5"];
    x.fillStyle="#5b3fd1";x.font="14px sans-serif";
    d.forEach(function(v,i){x.fillRect(30+i*85,220-v*20,50,v*20);x.fillText(l[i],42+i*85,235);x.fillText(v+"h",42+i*85,214-v*20);});
  }
})();
